package com.example.dias.Dias;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiasApplicationTests {

	@Test
	void contextLoads() {
	}

}

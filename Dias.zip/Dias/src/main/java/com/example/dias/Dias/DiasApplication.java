package com.example.dias.Dias;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiasApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiasApplication.class, args);
	}

}
